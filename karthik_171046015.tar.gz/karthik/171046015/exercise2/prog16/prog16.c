#include<stdio.h>
#include<string.h>
#include<assert.h>

int start_index(char string1[10]);
int main()
{
	
         start_index("ould");

	return 0;
}


int start_index(char string1[10])
{

	int i,j,str1len,str2len,found=0, c;
	char string[256] = "I would love to come to your party! Thank you for inviting me.";
	
	str1len = strlen(string);
	str2len = strlen(string1);
	for (i=0;i<str1len - str2len;i++)
	{       c= str2len;
		
		for(j=0;j<str2len;j++)
		{
			if (string[i+j]==string1[j])
				
                                c--;
				//break;

		}
              if (c == 0) 
		{
		 found = 1;
		break;
  		}
}
		if (found == 1)
		{
			printf("%s found at index: %d\n",string1,i);
			return i;
		}



	return 0;
	
}