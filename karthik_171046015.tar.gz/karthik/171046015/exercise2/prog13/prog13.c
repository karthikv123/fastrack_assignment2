/*
	program to Check entered number is a palindrome.

*/
#include <stdio.h>
#include <assert.h>

int palindromeCheck(int);
void main()
{
	
	int origin;
	printf("Enter any number: ");
	scanf("%d",&origin);

	if(palindromeCheck(origin))
		printf("\nEnter number is a Palindrome\n");
	else
		printf("\nEnter number is a not a Palindrome\n");

	assert(palindromeCheck(45654) == 1);
	assert(palindromeCheck(12321) == 1);
	assert(palindromeCheck(85251) == 1);
	
}

int palindromeCheck(int origin)
{
	int rem,rev = 0,num;
	num = origin;
	
	while(num != 0)
	{
		rem  = num % 10;
		rev = rev + rem;
		num = num/10;
		rev = rev * 10;
	}
	rev = rev / 10;
	if(rev == origin)
		return 1;
	else 
		return 0;
}
