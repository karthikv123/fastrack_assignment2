/* 
	program to check year is a leap year or not

*/

#include <stdio.h>
#include <assert.h>

int leapyear(int n);

void main()
{
	assert(leapyear(2016)==1);
	assert(leapyear(2017)==0);
}

int leapyear(int n)
{
	int year;

	year=n%4;
	
	if(year==0)
	{
		printf("%d is a leapyear\n",n);
		return 1;
	}
	else
	{
		printf("%d is not a leapyear\n",n);
		return 0;
	}
}
