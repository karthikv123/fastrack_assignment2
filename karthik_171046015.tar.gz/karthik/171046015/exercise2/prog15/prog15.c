/*
	program to 15. Compute the power of an integer ‘m’, raised to a positive integer ‘n’. 
*/

#include <stdio.h>
#include <assert.h>

long int computePower(int m, int n);
void main()
{
	int base, power;
	
	printf("Enter the base and power numbers: ");
	scanf("%d %d",&base,&power);

	printf("\n%d power %d = %ld\n",base,power,computePower(base,power));

	assert(computePower(5,3) == 125);
	assert(computePower(6,4) == 1295);


}

long int computePower(int base, int power)
{

	long int res = 1;
	int i;
	for (i=1;i<=power;i++)
	{
		res = res * base;	
	}
		return res;
}
