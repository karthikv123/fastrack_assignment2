//Write a program to check whether two files are same.

#include<stdio.h>
#include<string.h>

void main()
{
	FILE *fp=fopen("feed.txt","r");
	FILE *fp1=fopen("output2.txt","r");
	char i[100],j[100],flag='s';
	while ((fscanf(fp,"%s",i))!=EOF)
	{
		fscanf(fp1,"%s",j);
		if (strcmp(i,j))
		{
			flag='1';
			printf("*** In file 1=%s In file 2=%s****\n",i,j);
		}
		
	}
	if (flag=='s')
		{
			printf("Same\n");
		}
		else
		{
			printf("DIfferent\n");
		}
	fclose(fp1);
	fclose(fp);
}