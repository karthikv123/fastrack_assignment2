//Write a program to copy the contents of one file to another.

#include<stdio.h>
void main()
{
	char i;
	FILE *fp1,*fp2;
	fp1= fopen("feed.txt","r");
	fp2= fopen("output.txt","w");
	i='c';
	while(i!=EOF)
	{
		fputc(i,fp2);
		fgetc(fp1);
	}
	putc(i,fp2);
	fclose(fp1);
	fclose(fp2);
}