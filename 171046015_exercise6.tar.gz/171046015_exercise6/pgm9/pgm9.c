//Write a program to reverse the same file.

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void main()
{
	FILE *fp,*fp1;
	int cnt,count,i;
	fp= fopen("feed.txt","r");
	fseek(fp,-1,SEEK_END);
	printf("%d",count=ftell(fp));
	char *str;
	str=malloc(2*cnt*sizeof(char));
	cnt=count;
	while(cnt--)
	{

		*(str+cnt)=fgetc(fp);
		fseek(fp,-2L,1);

	}
	rewind(fp);
	unlink("feed.txt");
	fp= fopen("feed.txt","w");
	for(i=count-1;i>=0;i--)
	{
		fprintf(fp, "%c",*(str+i));
	}
}