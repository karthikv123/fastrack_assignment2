//Write the contents of a file in reversed order into another file.

#include<stdio.h>
void main()
{
	FILE *fp,*fp1;
	int cnt;
	fp= fopen("feed.txt","r");
	fp1=fopen("rev.txt","w");
	fseek(fp,-1,SEEK_END);
	printf("%d",cnt=ftell(fp));
	while(cnt--)
	{

		fputc(fgetc(fp),fp1);
		fseek(fp,-2L,1);

		//printf("%ld:==\n",ftell(fp));

	}
}