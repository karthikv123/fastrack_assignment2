//Write a simple program to display the contents of a file.

#include<stdio.h>
void main()
{
	char i;
	FILE *fp;
	fp= fopen("feed.txt","r");
	i=fgetc(fp);
	while(i!=EOF)
	{
		printf("%c",i);
		i=fgetc(fp);
	}
	fclose(fp);
}