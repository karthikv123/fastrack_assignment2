/*
Read a file which contains one number per line. Check the number is odd or even and write to corresponding files. 
Note: Numbers may not be single digit numbers.
*/

#include<stdio.h>
void main()
{
	FILE *fp=fopen("feed.txt","r");
	FILE *fp1=fopen("output.txt","w");
	int i;
	while ((fscanf(fp,"%d",&i))!=EOF)
	{
		if (i%2==0)
		{
			fprintf(fp1,"%s","Even\n");
		}
		else
		{
			fprintf(fp1,"%s","Odd\n");
		}
	}
	fclose(fp1);
	fclose(fp);
}