//Modify program 11 such that files A and B are not presorted.

#include<stdio.h>
#include<stdlib.h>
void fsort ( FILE *fp);
int no_of_lines(FILE *fp);	
void bsort(int * fake_array,int n);
void main()
{
	FILE *fp,*fp1,*fp2;
	fp=fopen("a1.txt","r");
	fp1=fopen("a2.txt","a");
	char buffer[250];
	while((fgets(buffer,250,fp)))
		fprintf(fp1,"%s",buffer);
	printf("here\n" );
	fclose(fp1);
	fclose(fp);
	fp2=fopen("a2.txt","r+");
	fsort(fp2);
	printf("there\n" );
	fclose(fp2);
}

void fsort( FILE *fp)
{
	int i=0,j=0;
	int *fake_array;
	fake_array=(int *) malloc(no_of_lines(fp)*sizeof(int *));
	char k;
	int length=no_of_lines(fp);
	while(!feof(fp))
	{
		fscanf(fp,"%d",(fake_array+i));
		i++;
	}
	bsort(fake_array,no_of_lines(fp));
	for (i=0;i<length;i++)
	{
		printf("\n %d ",*(fake_array+i));
	}
	for (i=0;i<length;i++)
	{
		fprintf(fp,"%d\n",*(fake_array+i));
	}

	
}

int no_of_lines(FILE *fp)
{
	int i=-1;
	char c;
	fseek(fp,0,SEEK_SET);
	while(!feof(fp))
	{
		fscanf(fp,"%c",&c);
		//printf(" *** c=%c *** ",c);
		if(c=='\n')
		{
			i++;
		}
	}
	fseek(fp,0,SEEK_SET);
	return i;
}

void bsort(int * fake_array,int n)
{
	for (int i = 0; i < n; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (*(fake_array+j) > *(fake_array+j+1)) {
                int temp = *(fake_array+j);
                *(fake_array+j) = *(fake_array+j+1);
                *(fake_array+j+1) = temp;
            }
        }
}
}