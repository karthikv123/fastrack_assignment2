//Modify the 2nd program by passing the file names as command line arguments.

#include<stdio.h>
#include<stdlib.h>
void main(int argc,char *argv[])
{
	//if (argc!=3)
	//{
	//	printf("The programs takes 2 arguments");
	//	exit(0);
	//printf("%s ",argv[1]);
	char i;
	FILE *fp1;
	FILE *fp2;
	fp1= fopen(argv[1],"r");
	fp2= fopen(argv[2],"w");
	i='c';
	while(i!=EOF)
	{
		fputc(i,fp2);
		i=fgetc(fp1);
	}
	putc(i,fp2);
	fclose(fp1);
	fclose(fp2); 
}