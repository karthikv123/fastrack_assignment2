//Write a program to count number of characters, spaces tabs and lines in a file.

#include<stdio.h>
void main()
{
	FILE *fp;
	char c;
	fp=fopen("feed.txt","r");
	c=fgetc(fp);
	int character,space,tabs;
	character=space=tabs=0;
	int lines=1;
	while (c!=EOF)
	{
		if (c!=' ')
		{
			character++;
		}
		if (c==' ')
		{
			space++;
		}
		if (c=='\t')
		{
			tabs++;
		}
		if (c=='\n')
		{
			lines++;
		}
		c=fgetc(fp);
	}
	printf("character:%d\nspace:%d\ntabs:%d\nlines:%d\n",character,space,tabs,lines);
	fclose(fp);
}