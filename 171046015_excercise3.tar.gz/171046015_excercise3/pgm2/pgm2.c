#include <stdio.h>
long reverse(long); 
 
int main()
{
   long n, r;
   printf("enter a number to be reversed:\n");
   scanf("%ld", &n);
 
   r = reverse(n);
 
   printf("reversed number is :%ld\n", r);
 
   return 0;
}
 
long reverse(long n) {
   static long r = 0;long r1;
 
   while(n!=0)
  {
        r1 = n%10;
        r = r*10 + r1;
        n /= 10;
    }
    return r;
   
   
} 

