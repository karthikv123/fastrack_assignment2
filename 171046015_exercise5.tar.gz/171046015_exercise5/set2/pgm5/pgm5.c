//Read the name which should include first name, middle name and last name in one string. 
//Split the string into first, middle and last names based on blank spaces.

#include<stdio.h>
#include<string.h>
void main()
{
	char name[50];
	int i=0;
	fgets(name,50,stdin);
	printf("%s",name);
	char *first,*middle,*last,*full;
	full=first=name;
	while(*full!=' ')
	{
		full++;
		i++;
	}
	*(first+i)='\0';
	printf("First:%s \n",first);
	full++;
	middle=full;
	i=0;
	while(*full!=' ')
	{
		full++;
		i++;
	}
	*(middle+i)='\0';
	printf("Middle:%s \n",middle);
	
	full++;
	last=full;
	printf("Last:%s ",last);
	
}