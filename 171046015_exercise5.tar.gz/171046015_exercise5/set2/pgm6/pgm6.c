/*
Design a structure which stores the information of the student like name, registration number, branch, CGPA and marks.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Student{
    char name[20];
    int reg;
    char branch[20];
    float cgpa;
    float marks;
};
int count = -1 ,y=0;
struct Student *ptr[10];
int Science_reg = 100 , Social_reg = 200 , Maths_reg = 300; // Assuming only three branches present
void addNew()
{
    char ch;
    do{
        count++;
        ptr[count] = (struct Student*) malloc(sizeof(struct Student));
        printf("Enter Student name: ");
        scanf("%s",ptr[count]->name);
        printf("Enter Branch (Science,Social,Maths): ");
        scanf("%s",ptr[count]->branch);
        printf("Enter %s marks: ",ptr[y]->name);
        scanf("%f",&ptr[y]->marks);
        printf("Enter %s CGPA:",ptr[y]->name);
        scanf("%f",&ptr[y]->cgpa);
        y++;
        if(!strcmp(ptr[count]->branch , "Science"))
            ptr[count]->reg = Science_reg++;
        else if(!strcmp(ptr[count]->branch , "Social"))
            ptr[count]->reg = Social_reg++;
        else if(!strcmp(ptr[count]->branch , "Maths"))
            ptr[count]->reg = Maths_reg++;
        printf("Do you wish to continue(y/n): ");
        scanf(" %c",&ch);
    }while(ch == 'y');
}
void displayMarks()
{
    printf("Students who scored more than 90:\n");
    printf("Name\tReg No.\n");
    for(int i=0;i<=count;i++){
        if(ptr[i]->marks > 90){
            printf("%s\t",ptr[i]->name);
            printf("%d\n",ptr[i]->reg);
        }
    }
}


void countStudents()
{
    printf("Total number of students:\n");
    printf("Science = %d\n",Science_reg-100);
    printf("Social = %d\n",Social_reg-200);
    printf("Maths = %d\n",Maths_reg-300);
}
void displayAll()
{
    printf("Students record:\n");
    printf("Name\tReg No.\tBranch\tMarks\tCGPA\n");
    for(int i=0;i<=count;i++){
        printf("%s\t",ptr[i]->name);
        printf("%d\t",ptr[i]->reg);
        printf("%s\t",ptr[i]->branch);
        printf("%f\t",ptr[i]->marks);
        printf("%f\t",ptr[i]->cgpa);
        printf("\n");
    }
}

int main()
{
    addNew();
    displayMarks();
    countStudents();
    displayAll();
    return 0;
}

