/*
	 Car is traveling at a speed of 80 km/hr and a truck is stationed at a distance of 30 mts.
	 Truck will start moving exactly after 3 second.
	 If the car driver applies brake now find out whether car will hit the truck or not.
	 ( distance =  ((initial velocity + final velocity )/2 ) * time  ).
*/	
#include <stdio.h>
#include <assert.h>
int collision(int distance,int carspeed,int time);
int velocity(int k);
void main()
{
	assert(collision(30,80,3)==1);
	assert(collision(200,90,3)==0);
}
int collision(int distance,int carspeed,int time)
{
	int dist,rel_dist;
	carspeed=velocity(carspeed);
	dist=(carspeed*time);
	rel_dist=distance-dist;
	if(rel_dist<0)
	{
		printf("Collision Occured!!!\n");
		return 1;
	}
	else
	{
		printf("Collision Evaded\n");
		return 0;
	}
}
int velocity(int k)
{
	int m;
	m=(k*1000)/3600;
	printf("%dkm/h velocity =%dm/s\n",k,m);
	return m;
	
}
