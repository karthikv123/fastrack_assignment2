/*
Program to compare whether the elements in two arrays are same.
*/

#include<stdio.h>
#include<assert.h>

int arr_comp(int *, int *);

int main()
{
	int arr_1[10],arr_2[10],i;

	printf("Enter ten elements in array 1:\n");
	for(i = 0; i < 10 ; i++)
		scanf("%d",&arr_1[i]);

	printf("Enter ten elements in array 2:\n");
	for(i = 0; i < 10 ; i++)
		scanf("%d",&arr_2[i]);

	//assert(arr_comp(arr_1,arr_2) == 1);
	assert(arr_comp(arr_1,arr_2) == 1);

	if(arr_comp(arr_1,arr_2))
		printf("The elements in array 1 and array 2 are the same.\n");
	else
		printf("The elements in array 1 and array 2 are different.\n");

	return 0;
}

int arr_comp(int *ptr1, int *ptr2)
{
	int i = 10;

	while(i)
	{
		if(*ptr1 != *ptr2)
			return 0;
	
		ptr1++;
		ptr2++;
		i--;
	}

return 1;
}